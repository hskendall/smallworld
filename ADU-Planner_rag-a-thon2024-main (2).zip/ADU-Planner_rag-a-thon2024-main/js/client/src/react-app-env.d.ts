declare module 'google-map-react';
