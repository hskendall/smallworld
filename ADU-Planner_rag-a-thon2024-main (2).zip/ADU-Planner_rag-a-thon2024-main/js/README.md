Directory for JavaScript and TypeScript -related projects and source files.

