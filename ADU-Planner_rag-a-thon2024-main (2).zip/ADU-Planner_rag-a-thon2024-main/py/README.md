Directory for Python-related projects and source files.
